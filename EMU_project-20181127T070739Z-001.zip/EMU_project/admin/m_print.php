<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
    text-align: left;    
}
</style>
<?php

require '../core/session.php';
require '../core/config.php';
require '../core/admin-key.php';
	echo "<div class='table-responsive'><table class='table table-bordered border = '2'' id='printTable' style='width:100%'><tr style='text-align:center'><th style='text-align:center'>RefNo.</th><th style='text-align:center'>RollNo</th><th style='text-align:center'>Name</th><th style='text-align:center'>PhoneNo</th><th style='text-align:center'>Complain</th><th style='text-align:center'>Status</th><th style='text-align:center'>Date</th></tr>";
		$id = $_GET['id'];
		$query1 = mysql_query("SELECT * FROM `cmp_log` WHERE id='$id'");
		while( $arry=mysql_fetch_array($query1) ) {
              $ref = $arry['ref_no'];
              $user_id = $arry['user_id'];
              $name = $arry['name'];
              $phone_no = $arry['phone no'];
			  $complain = $arry['complain'];
			  $status = $arry['status'];
			  $date = $arry['date'];
              
            }
		echo "<tr style='text-align:center'><td>". $ref. "</td><td>".$user_id."</td><td>".$name."</td><td>".$phone_no."</td><td>".$complain."</td><td>".$status."</td><td>".$date."</td></tr>";
		 echo "</table></div>";
?>
<script src="jquery-1.8.1.min.js" type="text/javascript"></script>
<button title="TO DOWNLAOD: CHOOSE SAVE AS PDF IN DESTINATION!">Print/Download List</button>
<script>
  function printData()
{
   var divToPrint=document.getElementById("printTable");
   newWin= window.open("");
   newWin.document.write(divToPrint.outerHTML);
   newWin.print();
   newWin.close();
}

$('button').on('click',function(){
printData();
});
  </script>