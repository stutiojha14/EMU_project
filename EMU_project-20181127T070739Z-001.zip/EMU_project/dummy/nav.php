<?php
  require 'session.php';
 ?>
    <nav class="eng">

      <ul>
        <li><a href="profile.php">Profile</a></li>
        <li><a href="message.php">Message</a></li>

      </ul>

    </nav>
